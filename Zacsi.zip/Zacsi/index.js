const url = "https://retoolapi.dev/VwGII6/data";
const nev = document.querySelector("#nev");
const hely = document.querySelector("#hely");
const ev = document.querySelector("#ev");
const gomb = document.querySelector("#gomb");
const gomb2 = document.querySelector("#gomb2");
const users = document.querySelector("#users");
gomb.addEventListener('click', insert);
gomb2.addEventListener('click', select);
document.addEventListener("DOMContentLoaded", select);




async function insert() {
    let name = nev.value;
    let where = hely.value;
    let date = ev.value;
    const person = {
        name: name,
        where: where,
        date: date,
    }
    if(where!="Fidesz")
    {
        alert("Rossz válasz,csak a Fidesz!") 
    }
    

  
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json"
        },
        body: JSON.stringify(person)
    });
    
    if (response.status === 201) {
        nev.value = "";
        hely.value = "";
        ev.value = "";
        select();
    }
}
function select() {
    
    while (users.lastchild) {
        users.removeChild(users.lastchild);
    }
    users.innerHTML = '';

    
    fetch(url)
        .then((response) => response.json())
        .then((data) => cards(data));

}

function cards(params) {
    console.log(params);
    for (let i = 0; i < params.length; i++) {
      
        const newCard = document.createElement('div');
        newCard.innerHTML = `<div class="card">
        <div class="card-header">
             ${params[i].name}
        </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Fidesz</li>
                <li class="list-group-item">${params[i].date}</li>
            </ul>
            </div>`;
        newCard.classList.add("col-md-6");
        newCard.classList.add("col-lg-4");
        users.appendChild(newCard);
        console.log(newCard.innerHTML);
    }

}