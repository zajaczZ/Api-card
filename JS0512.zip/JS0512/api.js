const base_url = "https://retoolapi.dev/Dnzq1s/data";

$(function() {
    listPeople();
    polic="#part_input".val("");


    $("#person-form").submit(function (e) { 
        e.preventDefault();
        const nev = $("#nev_input").val();
        const partid = $("#partid_input").val();
        const part = $("#part_input").val();
        const person = {
            nev: nev,
            partid: partid,
            part: part
        }
       
        $.post(base_url, person,
            function (data, textStatus, jqXHR) {
                if (textStatus === "success") {
                    $("#nev_input").val("");
                    $("#partid_input").val("");
                    $("#part_input").val("");
                    listPeople();
                    let polic = person.part;
           
                }
            },
            "json"
        );
    });
});

function listPeople() {
    
    $.get(base_url, function(data, textStatus) {
        let html = "";
        
        data.forEach(person => {
            html += `<tr>
                <td>${person.id}</td>
                <td>${person.nev}</td>
                <td>${person.partid}</td>
                <td>Fidesz </td>
            </tr>`;
        });
        $("#people-table").html(html);
    },
    "json");
   
}

/*
function deletePerson(personId) {
    $.ajax({
        type: "DELETE",
        url: `${base_url}/${personId}`,
        dataType: "json",
        success: function (data, textStatus, jqXHR) {
            if (textStatus === "success") {
                listPeople();
            }
        }
    });
}*/